<?php

namespace App\Http\Controllers;

use App\Models\TransactionAdditional;
use Illuminate\Http\Request;

class TransactionAdditionalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\TransactionAdditional  $transactionAdditional
     * @return \Illuminate\Http\Response
     */
    public function show(TransactionAdditional $transactionAdditional)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\TransactionAdditional  $transactionAdditional
     * @return \Illuminate\Http\Response
     */
    public function edit(TransactionAdditional $transactionAdditional)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\TransactionAdditional  $transactionAdditional
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, TransactionAdditional $transactionAdditional)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\TransactionAdditional  $transactionAdditional
     * @return \Illuminate\Http\Response
     */
    public function destroy(TransactionAdditional $transactionAdditional)
    {
        //
    }
}
