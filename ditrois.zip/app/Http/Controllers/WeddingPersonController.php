<?php

namespace App\Http\Controllers;

use App\Models\WeddingPerson;
use Illuminate\Http\Request;

class WeddingPersonController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\WeddingPerson  $weddingPerson
     * @return \Illuminate\Http\Response
     */
    public function show(WeddingPerson $weddingPerson)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\WeddingPerson  $weddingPerson
     * @return \Illuminate\Http\Response
     */
    public function edit(WeddingPerson $weddingPerson)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\WeddingPerson  $weddingPerson
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, WeddingPerson $weddingPerson)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\WeddingPerson  $weddingPerson
     * @return \Illuminate\Http\Response
     */
    public function destroy(WeddingPerson $weddingPerson)
    {
        //
    }
}
