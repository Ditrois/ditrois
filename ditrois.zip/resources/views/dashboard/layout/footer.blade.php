<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2022 <div class="bullet"></div> Ditrois All Rights Reserved
    </div>
</footer>
