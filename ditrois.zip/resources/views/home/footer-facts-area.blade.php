<!-- Cool Footer Facts Area-->
<div class="cta-area pt-120 pb-120 bg-img bg-fixed bg-overlay" style="background-image: url('img/bg-img/1.jpg');">
    <div class="container">
    <div class="row">
        <div class="col-12 col-sm-10 col-md-8">
        <div class="cta-text">
            <h2 class="mb-4 mb-lg-5 wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="200ms">Kembangkan website dengan design dan performa terbaik untuk mendukung performa bisnis anda.</h2><a class="btn btn-warning wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="400ms" href="https://wa.me/6285161830939?text=Hi,%20Saya%20ingin%20membuat%20website">Hubungi Kami</a>
        </div>
        </div>
    </div>
    </div>
</div>
<div class="mb-120 d-block"></div>