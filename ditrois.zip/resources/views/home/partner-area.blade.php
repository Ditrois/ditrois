<!-- Partner Area-->
<div class="partner-area">
    <div class="container">
    <div class="row">
        <div class="col-12">
        <div class="section-heading text-center">
            <h2 class="mb-0">Trusted and used by 2k+ creative company.</h2>
        </div>
        </div>
    </div>
    </div>
    <div class="container">
    <div class="partner-wrapper">
        <!-- Logo -->
        <div class="partner-logo px-sm-3"><img src="{{ asset('img/partner-img/1.png') }}" alt=""></div>
        <!-- Logo -->
        <div class="partner-logo px-sm-3"><img src="{{ asset('img/partner-img/2.png') }}" alt=""></div>
        <!-- Logo -->
        <div class="partner-logo px-sm-3"><img src="{{ asset('img/partner-img/3.png') }}" alt=""></div>
        <!-- Logo -->
        <div class="partner-logo px-sm-3"><img src="{{ asset('img/partner-img/4.png') }}" alt=""></div>
        <!-- Logo -->
        <div class="partner-logo px-sm-3"><img src="{{ asset('img/partner-img/5.png') }}" alt=""></div>
        <!-- Logo -->
        <div class="partner-logo px-sm-3"><img src="{{ asset('img/partner-img/6.png') }}" alt=""></div>
        <!-- Logo -->
        <div class="partner-logo px-sm-3"><img src="{{ asset('img/partner-img/1.png') }}" alt=""></div>
        <!-- Logo -->
        <div class="partner-logo px-sm-3"><img src="{{ asset('img/partner-img/2.png') }}" alt=""></div>
        <!-- Logo -->
        <div class="partner-logo px-sm-3"><img src="{{ asset('img/partner-img/3.png') }}" alt=""></div>
        <!-- Logo -->
        <div class="partner-logo px-sm-3"><img src="{{ asset('img/partner-img/4.png') }}" alt=""></div>
    </div>
    </div>
</div>
<div class="mb-120 d-block"></div>