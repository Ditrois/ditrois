

<?php $__env->startSection('title', 'All Services'); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('dashboard.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
        </div>
        
        <?php echo $__env->make('dashboard.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="section-body">
        <div class="row">
        <div class="col-lg-12 col-md-12 col-12 col-sm-12">
              <div class="card">
                <div class="card-header">
                  <h4>Latest Posts</h4>
                  <div class="card-header-action">
                    <a href="/dashboard/admin/service/new" class="btn btn-primary">New Service</a>
                  </div>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive">
                    <table class="table table-striped mb-0">
                      <thead>
                        <tr>
                          <th>Name</th>
                          <th>Category</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                            <?php echo e($service->name); ?>

                          </td>
                          <td>
                            <?php echo e($service->service_category->name); ?>

                          </td>
                          <td>
                            <a href="https://ditrois.com//<?php echo e($service->service_category->slug); ?>/<?php echo e($service->slug); ?>" class="btn btn-success btn-action mr-1">
                                    <i class="fas fa-eye"></i>
                            </a>
                            <a href="/dashboard/admin/service/edit/<?php echo e($service->id); ?>" class="btn btn-primary btn-action mr-1">
                                    <i class="fas fa-pencil-alt"></i>
                            </a>
                            <a href="/dashboard/admin/service/delete/<?php echo e($service->id); ?>" class="btn btn-danger btn-action" onclick="return confirm ('Hapus service?')">
                                    <i class="fas fa-trash"></i>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ditrois\resources\views/dashboard/admin/services.blade.php ENDPATH**/ ?>