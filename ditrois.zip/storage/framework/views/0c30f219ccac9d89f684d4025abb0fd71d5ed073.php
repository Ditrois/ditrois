<?php $__env->startSection('content'); ?>
  <?php echo $__env->make('home.welcome-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- include('home.about-area') -->
  <?php echo $__env->make('home.facts-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('home.service-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- include('home.features-area') -->
  <!-- include('home.dinamic-features-area') -->
  <?php echo $__env->make('home.pricing-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- include('home.portfolio-area') -->
  <!-- include('home.team-area') -->
  <!-- include('home.client-feedback-area') -->
  <!-- include('home.partner-area') -->
  <!-- include('home.news-area') -->
  <?php echo $__env->make('home.footer-facts-area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ditrois\resources\views/welcome.blade.php ENDPATH**/ ?>