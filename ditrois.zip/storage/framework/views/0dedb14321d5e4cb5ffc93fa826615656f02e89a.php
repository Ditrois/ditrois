<!DOCTYPE html>
<html lang="id">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Ditrois - Website and Software Development Company">
    <!-- Title-->
    <title>Ditrois - Website and Software Development Company</title>
    <!-- Favicon-->
    <link rel="shortcut icon" href="<?php echo e(asset('img/core-img/favicon.ico')); ?>" type="image/x-icon">
    <!-- All CSS Stylesheet-->
    <link rel="stylesheet" href="<?php echo e(asset('css/all-css-libraries.css')); ?>">
    <!-- Core Stylesheet-->
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>">
  </head>
  <body>
    <!-- Preloader-->
    <!-- <div class="preloader" id="preloader">
      <div class="spinner-grow text-light" role="status"><span class="visually-hidden">Loading...</span></div>
    </div> -->
    <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\ditrois\resources\views/layouts/app.blade.php ENDPATH**/ ?>