

<?php $__env->startSection('title', 'Saldo'); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('dashboard.affiliator.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
        </div>

        <div class="section-body">


        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                  <i class="far fa-user"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Saldo</h4>
                  </div>
                  <div class="card-body">
                    Rp<?php echo e(number_format($affiliator->saldo)); ?>

                  </div>
                </div>
              </div>
            </div>
          </div>


          <div class="row">
        <div class="col-md-12"><div class="card">
        <div class="card-header">
          <h4>Tarik Saldo</h4>
        </div>
        <div class="card-body">
          <form action="/dashboard/affiliator/payment/withdraw" method="post">
              <?php echo csrf_field(); ?>
            <div class="form-group row">
              <label class="col-form-label text-md-center col-12 col-md-12 col-lg-12">
                INFORMASI PENARIKAN :<br><?php echo e($affiliator->bank); ?><br><?php echo e($affiliator->no_rekening); ?><br><?php echo e($affiliator->nama); ?></label>
            </div>
            <div class="form-group row mb-1">
              <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Jumlah Penarikan</label>
              <div class="col-sm-12 col-md-7">
                <input name="amount" type="number" class="form-control" value="" required min="25000">
              </div>
            </div>
            <div class="form-group row mb-4">
              <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
              
              <div class="col-sm-12 col-md-7 d-flex justify-content-center">
                <a href="/dashboard/affiliator/payment/edit" class="btn btn-warning mr-2">Ubah Nomor Rekening</a>
                <button type="submit" class="btn btn-primary mr-2">Tarik</button>
              </div>
            </div>
          </form>
        </div>
        
        <div class="card-footer bg-whitesmoke">
          <!-- Ketika ada seseorang yang mengakses link yang berisikan kode afilliasimu, kamu akan mendapatkan komisi sebesar 25% dari total transaksi yang orang tersebut lakukan dalam 3 bulan setelah ia pertama kali mengakses link yang berisikan kode affiliasimu. -->
        </div>
      </div>
              <div class="card">
                <div class="card-header">
                  <h4>Riwayat Penarikan</h4>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive table-invoice">
                    <table class="table table-striped">
                      <tr>
                        <th>Jumlah</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th>Action</th>
                      </tr>
                      <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td class="font-weight-600">Rp<?php echo e(number_format($withdraw->amount)); ?></td>
                        <td>
                          <?php if($withdraw->status == 'pending'): ?>
                            <div class="badge badge-warning">Pending</div>
                          <?php elseif($withdraw->status == 'rejeced'): ?>
                            <div class="badge badge-danger">Rejected</div>
                          <?php else: ?>
                            <div class="badge badge-success">Paid</div>
                          <?php endif; ?>
                        </td>
                        <td><?php echo e($withdraw->created_at); ?></td>
                        <td>
                          <a href="/dashboard/affiliator/payment/detail/<?php echo e($withdraw->id); ?>" class="btn btn-primary">Detail</a>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ditrois\resources\views/dashboard/affiliator/payment.blade.php ENDPATH**/ ?>