

<?php $__env->startSection('title', 'Update Transaction'); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('dashboard.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
        <section class="section">
          <div class="section-header">
            <!-- <div class="section-header-back">
              <a href="features-posts.html" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
            </div> -->
            <h1>Update Transaction</h1>
            <!-- <div class="section-header-breadcrumb">
              <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
              <div class="breadcrumb-item"><a href="#">Posts</a></div>
              <div class="breadcrumb-item">Create New Post</div>
            </div> -->
          </div>

          <div class="section-body">
            <!-- <h2 class="section-title">Create New Post</h2>
            <p class="section-lead">
              On this page you can create a new post and fill in all fields.
            </p> -->

            <div class="row">
              <div class="col-12">
                <div class="card">
                  <!-- <div class="card-header">
                    <h4>Write Your Post</h4>
                  </div> -->
                  <div class="card-body">
                    
                  
                  <?php if(count($errors) > 0): ?>
                  <div class="alert alert-danger">
                      <ul>
                          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <li><?php echo e($error); ?></li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </ul>
                  </div>
                  <?php endif; ?>
                  <form action="/dashboard/admin/transaction/update/<?php echo e($transaction->id); ?>" method="post">
                      <?php echo csrf_field(); ?>
                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Service</label>
                      <div class="col-sm-12 col-md-7">
                        <select class="form-control selectric" name="id_service">
                          <option>Pilih Service</option>
                          <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($transaction->id_service == $service->id): ?>
                                <option value="<?php echo e($service->id); ?>" selected><?php echo e($service->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($service->id); ?>"><?php echo e($service->name); ?></option>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Package</label>
                      <div class="col-sm-12 col-md-7">
                        <select class="form-control selectric" name="id_package">
                          <option>Pilih Package</option>
                          <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($transaction->id_package == $package->id): ?>
                                <option value="<?php echo e($package->id); ?>" selected><?php echo e($package->service->name); ?> - <?php echo e($package->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($package->id); ?>"><?php echo e($package->service->name); ?> - <?php echo e($package->name); ?></option>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Theme</label>
                      <div class="col-sm-12 col-md-7">
                        <select class="form-control selectric" name="id_theme">
                          <option>Pilih Theme</option>
                          <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($transaction->id_theme == $theme->id): ?>
                                <option value="<?php echo e($theme->id); ?>" selected><?php echo e($theme->service->name); ?> - <?php echo e($theme->name); ?></option>
                            <?php else: ?>
                                <option value="<?php echo e($theme->id); ?>"><?php echo e($theme->service->name); ?> - <?php echo e($theme->name); ?></option>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      </div>
                    </div>
                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Customer Name</label>
                      <div class="col-sm-12 col-md-7">
                        <input type="text" name="customer_name" class="form-control" value="<?php echo e($transaction->customer_name); ?>">
                      </div>
                    </div>
                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Cutomer Phone Number</label>
                      <div class="col-sm-12 col-md-7">
                        <input type="text" name="customer_phone_number" class="form-control" value="<?php echo e($transaction->customer_phone_number); ?>">
                      </div>
                    </div>
                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Result Link</label>
                      <div class="col-sm-12 col-md-7">
                        <input type="text" name="result_link" class="form-control" value="<?php echo e($transaction->result_link); ?>">
                      </div>
                    </div>
                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Status</label>
                      <div class="col-sm-12 col-md-7">
                        <select class="form-control selectric" name="status" id="status">
                          <option value="pending">pending</option>
                          <option value="approved">approved</option>
                          <option value="complete">complete</option>
                          <option value="refund">refund</option>
                          <option value="rejeced">rejected</option>
                        </select>
                      </div>
                    </div>
                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                      <div class="col-sm-12 col-md-7">
                        <button class="btn btn-primary">Update Transaction</button>
                      </div>
                    </div>
                  </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
      <script>
        document.getElementById("status").value = "<?php echo e($transaction->status); ?>";
      </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ditrois\resources\views/dashboard/admin/transaction_edit.blade.php ENDPATH**/ ?>