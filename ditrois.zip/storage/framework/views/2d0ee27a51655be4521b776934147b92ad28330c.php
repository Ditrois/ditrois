

<?php $__env->startSection('title', 'All Categories'); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('dashboard.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
        </div>
        
        <?php echo $__env->make('dashboard.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="section-body">

        <div class="row">
        <div class="col-lg-12 col-md-12 col-12 col-sm-12">
              <div class="card">
                <div class="card-header">
                  <h4>Latest Category</h4>
                  <div class="card-header-action">
                    <a href="/dashboard/admin/category/new" class="btn btn-primary">New Category</a>
                  </div>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive">
                    <table class="table table-striped mb-0">
                      <thead>
                        <tr>
                          <th>Name</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                            <?php echo e($category->name); ?>

                            <div class="table-links">
                              <a href="/<?php echo e($category->slug); ?>">View Page</a>
                            </div>
                          </td>
                          <td>
                            <a href="/dashboard/admin/category/edit/<?php echo e($category->id); ?>" class="btn btn-primary btn-action mr-1">
                                    <i class="fas fa-pencil-alt"></i>
                            </a>
                            <a href="/dashboard/admin/category/delete/<?php echo e($category->id); ?>" class="btn btn-danger btn-action" onclick="return confirm ('Hapus kategori?')">
                                    <i class="fas fa-trash"></i>
                            </a>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ditrois\resources\views/dashboard/admin/categories.blade.php ENDPATH**/ ?>