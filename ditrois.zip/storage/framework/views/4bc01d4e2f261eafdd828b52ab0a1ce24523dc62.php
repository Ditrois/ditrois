<aside id="sidebar-wrapper">
    <div class="sidebar-brand">
        <a href="/">Distrois</a>
    </div>
    <div class="sidebar-brand sidebar-brand-sm">
        <a href="/">Distrois</a>
    </div>
    <ul class="sidebar-menu">
        <li class="">
            <a href="/dashboard/affiliator" class="nav-link">
                <i class="fas fa-fire"></i>
                <span>Dashboard</span>
            </a>
        </li>
        <li class="">
            <a class="nav-link" href="/dashboard/affiliator/code">
                <i class="fas fa-file"></i>
                <span>Your Code</span>
            </a>
        </li>
        <li class="">
            <a class="nav-link" href="/dashboard/affiliator/transaction">
                <i class="fas fa-ring"></i>
                <span>Transaction</span>
            </a>
        </li>
        <li class="">
            <a class="nav-link" href="/dashboard/affiliator/payment">
                <i class="fas fa-users"></i>
                <span>Saldo</span>
            </a>
        </li>
        <!-- <li class="">
            <a class="nav-link" href="/dashboard/affiliator/account">
                <i class="fas fa-user"></i>
                <span>Account Setting</span>
            </a>
        </li> -->
</aside>
<?php /**PATH C:\ditrois\resources\views/dashboard/affiliator/sidebar.blade.php ENDPATH**/ ?>