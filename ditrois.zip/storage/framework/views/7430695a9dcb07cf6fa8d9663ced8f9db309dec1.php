

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('dashboard.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
        </div>

        <div class="section-body">


        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                  <i class="far fa-user"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Services</h4>
                  </div>
                  <div class="card-body">
                    <?php echo e($serviceCount); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-danger">
                  <i class="far fa-newspaper"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Transaction</h4>
                  </div>
                  <div class="card-body">
                    <?php echo e($transactions->count()); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-warning">
                  <i class="far fa-file"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Weddings</h4>
                  </div>
                  <div class="card-body">
                  <?php echo e($weddingCount); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-success">
                  <i class="fas fa-circle"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Affiliators</h4>
                  </div>
                  <div class="card-body">
                    <?php echo e($affiliatorCount); ?>

                  </div>
                </div>
              </div>
            </div>
          </div>


        <div class="row">
        <div class="col-lg-8 col-md-8 col-12 col-sm-12">
              <div class="card">
                <div class="card-header">
                  <h4>Transaction List</h4>
                  <div class="card-header-action">
                    <a href="/dashboard/admin/transaction/new" class="btn btn-primary">Create Transaction</a>
                  </div>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive">
                    <table class="table table-striped mb-0">
                      <thead>
                        <tr>
                          <th>Customer</th>
                          <th>Status</th>
                          <th>Date</th>
                          <th>Total</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                            <?php echo e($transaction->customer_name); ?>

                          </td>
                          <td>
                            <?php if($transaction->status == 'pending'): ?>
                              <div class="badge badge-warning">Unpaid</div>
                            <?php elseif($transaction->status == 'rejeced'): ?>
                              <div class="badge badge-danger">Rejected</div>
                            <?php elseif($transaction->status == 'refund'): ?>
                              <div class="badge badge-danger">Refund</div>
                            <?php else: ?>
                              <div class="badge badge-success">Paid</div>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php echo e($transaction->created_at); ?>

                          </td>
                          <td>
                            Rp<?php echo e(number_format($transaction->total)); ?>

                          </td>
                          <td>
                            <?php if(isset($transaction->result_link)): ?>
                            <a href="<?php echo e($transaction->result_link); ?>" class="btn btn-success btn-action mr-1">
                                    <i class="fas fa-eye"></i>
                            </a>
                            <?php endif; ?>
                            <a href="/dashboard/admin/transaction/edit/<?php echo e($transaction->id); ?>" class="btn btn-primary btn-action mr-1">
                                    <i class="fas fa-pencil-alt"></i>
                            </a>
                            <a href="/dashboard/admin/transaction/delete/<?php echo e($transaction->id); ?>" class="btn btn-danger btn-action" onclick="return confirm ('Hapus transaksi?')">
                                    <i class="fas fa-trash"></i>
                            </a>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-12 col-sm-12">
              <div class="card">
                <div class="card-header">
                  <h4 class="d-inline">Withdraw Request</h4>
                  <!-- <div class="card-header-action">
                    <a href="#" class="btn btn-primary">View All</a>
                  </div> -->
                </div>
                <div class="card-body">
                  <ul class="list-unstyled list-unstyled-border">
                    <?php $__currentLoopData = $affiliatorWithdrawals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affiliatorWithdrawal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="media">
                      <div class="media-body">
                        
                        <div class="mb-1 float-right">
                        <a href="/dashboard/admin/affiliator/edit/<?php echo e($affiliatorWithdrawal->id); ?>" class="btn btn-success btn-action mr-1" title="Bayar">Bayar</a>
                        </div>
                        <h6 class="media-title">Rp<?php echo e(number_format($affiliatorWithdrawal->amount)); ?></h6>
                        <div class="text-small text-muted"><?php echo e($affiliatorWithdrawal->affiliator->user->name); ?></div>
                      </div>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div>
              </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ditrois\resources\views/dashboard/index.blade.php ENDPATH**/ ?>