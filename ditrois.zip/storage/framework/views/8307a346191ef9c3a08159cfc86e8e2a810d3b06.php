

<?php $__env->startSection('title', 'Edit Rekening'); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('dashboard.affiliator.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
        </div>

        <div class="section-body">


          <div class="row">
        <div class="col-md-12"><div class="card">
        <div class="card-header">
          <h4>Update Rekening Penerima</h4>
        </div>
        <div class="card-body">
          <form action="/dashboard/affiliator/payment/update" method="post">
              <?php echo csrf_field(); ?>
            <div class="form-group row mb-1">
              <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Bank</label>
              <div class="col-sm-12 col-md-7">
                <input name="bank" type="text" class="form-control" value="<?php echo e($affiliator->bank); ?>">
                <p>Bisa diisi bank/dompet digital seperti Gopay, Ovo, Dana, Dll</p>
              </div>
            </div>
            <div class="form-group row mb-1">
              <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Nomor Rekening</label>
              <div class="col-sm-12 col-md-7">
                <input name="no_rekening" type="text" class="form-control" value="<?php echo e($affiliator->no_rekening); ?>">
                <p>Untuk bank/dompet digital seperti Gopay, Ovo, Dana, dll bisa diisi nomor telepon atau kode user yang bisa digunakan untuk transfer</p>
              </div>
            </div>
            <div class="form-group row mb-1">
              <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Atas Nama</label>
              <div class="col-sm-12 col-md-7">
                <input name="nama" type="text" class="form-control" value="<?php echo e($affiliator->nama); ?>">
              </div>
            </div>
            <div class="form-group row mb-4">
              <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
              <div class="col-sm-12 col-md-7 d-flex justify-content-center">
                <button type="submit" class="btn btn-primary mr-2">Simpan</button>
              </div>
            </div>
          </form>
        </div>
        
        <div class="card-footer bg-whitesmoke">
          <!-- Ketika ada seseorang yang mengakses link yang berisikan kode afilliasimu, kamu akan mendapatkan komisi sebesar 25% dari total transaksi yang orang tersebut lakukan dalam 3 bulan setelah ia pertama kali mengakses link yang berisikan kode affiliasimu. -->
        </div>
      </div>
              
            </div>
            </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ditrois\resources\views/dashboard/affiliator/payment_edit_norek.blade.php ENDPATH**/ ?>