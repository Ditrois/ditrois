

<?php $__env->startSection('title', 'Transaction'); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('dashboard.affiliator.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
        </div>

        <div class="section-body">


        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-primary">
                  <i class="far fa-user"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Semua Transaksi</h4>
                  </div>
                  <div class="card-body">
                    <?php echo e($transactionCount); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-danger">
                  <i class="far fa-newspaper"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Belum Dibayar</h4>
                  </div>
                  <div class="card-body">
                    <?php echo e($unpaidTransactionCount); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-warning">
                  <i class="far fa-file"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Total Komisi</h4>
                  </div>
                  <div class="card-body">
                    Rp<?php echo e(number_format($transactionSum)); ?>

                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
              <div class="card card-statistic-1">
                <div class="card-icon bg-success">
                  <i class="fas fa-circle"></i>
                </div>
                <div class="card-wrap">
                  <div class="card-header">
                    <h4>Peluang Komisi</h4>
                  </div>
                  <div class="card-body">
                    Rp<?php echo e(number_format($unpaidTransactionSum)); ?>

                  </div>
                </div>
              </div>
            </div>
          </div>


        <div class="row">
        <div class="col-md-12">
              <div class="card">
                <div class="card-header">
                  <h4>Riwayat Transaksi Afiliate</h4>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive table-invoice">
                    <table class="table table-striped">
                      <tr>
                        <th>Jumlah</th>
                        <th>Status</th>
                        <th>Tanggal</th>
                      </tr>
                      <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td>Rp<?php echo e(number_format($transaction->total)); ?></td>
                        <td>
                          <?php if($transaction->status == 'pending'): ?>
                            <div class="badge badge-warning">Unpaid</div>
                          <?php elseif($transaction->status == 'rejeced'): ?>
                            <div class="badge badge-danger">Rejected</div>
                          <?php elseif($transaction->status == 'refund'): ?>
                            <div class="badge badge-danger">Refund</div>
                          <?php else: ?>
                            <div class="badge badge-success">Paid</div>
                          <?php endif; ?>
                        </td>
                        <td><?php echo e($transaction->created_at); ?></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ditrois\resources\views/dashboard/affiliator/transaction.blade.php ENDPATH**/ ?>