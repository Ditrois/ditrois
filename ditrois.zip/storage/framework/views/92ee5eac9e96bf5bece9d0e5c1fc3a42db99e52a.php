

<?php $__env->startSection('title', 'Detail Penarikan'); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('dashboard.affiliator.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
  <section class="section">
    <div class="section-header">
      <h1><?php echo $__env->yieldContent('title'); ?></h1>
    </div>

    <div class="section-body">
      <div class="card">
        <div class="card-body">
          <div class="form-group row mb-1">
            <!-- <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Affiliate Link</label> -->
            <div class="col-sm-12 col-md-7">
              ID Penarikan : <?php echo e($withdraw->id); ?> <br>
              Jumlah : Rp<?php echo e(number_format($withdraw->amount)); ?> <br>
              Bank : <?php echo e($withdraw->bank); ?> <br>
              No Rekening : <?php echo e($withdraw->no_rekening); ?> <br>
              Atas Nama : <?php echo e($withdraw->nama); ?> <br>
              Status : <?php echo e($withdraw->status); ?> <br> <br>
              <img style="overflow: hidden;" class="card-img-top rounded-lg mx-auto d-block" src="/affiliate/withdraw/<?php echo e($withdraw->withdraw_proof); ?>" alt="Belum ada bukti pengiriman saldo yg ditarik, harap tunggu, maksimal 3 hari setelah penarikan dilakukan">
            </div>
          </div>
        </div>
        
        <div class="card-footer bg-whitesmoke"></div>
      </div>
    </div>
  </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ditrois\resources\views/dashboard/affiliator/payment_detail.blade.php ENDPATH**/ ?>