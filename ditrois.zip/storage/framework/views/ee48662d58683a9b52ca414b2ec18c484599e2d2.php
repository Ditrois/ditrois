

<?php $__env->startSection('title', 'All Transactions'); ?>

<?php $__env->startSection('sidebar'); ?>
<?php echo $__env->make('dashboard.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Main Content -->
<div class="main-content">
    <section class="section">
        <div class="section-header">
            <h1><?php echo $__env->yieldContent('title'); ?></h1>
        </div>
        <?php echo $__env->make('dashboard.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="section-body">

        <div class="row">
        <div class="col-lg-12 col-md-12 col-12 col-sm-12">
              <div class="card">
                <div class="card-header">
                  <h4>Transaction List</h4>
                  <div class="card-header-action">
                    <a href="/dashboard/admin/transaction/new" class="btn btn-primary">Create Transaction</a>
                  </div>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive">
                    <table class="table table-striped mb-0">
                      <thead>
                        <tr>
                          <th>Customer</th>
                          <th>Status</th>
                          <th>Date</th>
                          <th>Total</th>
                          <th>Action</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td>
                            <?php echo e($transaction->customer_name); ?>

                          </td>
                          <td>
                            <?php if($transaction->status == 'pending'): ?>
                              <div class="badge badge-warning">Unpaid</div>
                            <?php elseif($transaction->status == 'rejeced'): ?>
                              <div class="badge badge-danger">Rejected</div>
                            <?php elseif($transaction->status == 'refund'): ?>
                              <div class="badge badge-danger">Refund</div>
                            <?php else: ?>
                              <div class="badge badge-success">Paid</div>
                            <?php endif; ?>
                          </td>
                          <td>
                            <?php echo e($transaction->created_at); ?>

                          </td>
                          <td>
                            Rp<?php echo e(number_format($transaction->total)); ?>

                          </td>
                          <td>
                            <?php if(isset($transaction->result_link)): ?>
                            <a href="<?php echo e($transaction->result_link); ?>" class="btn btn-success btn-action mr-1">
                                    <i class="fas fa-eye"></i>
                            </a>
                            <?php endif; ?>
                            <a href="/dashboard/admin/transaction/edit/<?php echo e($transaction->id); ?>" class="btn btn-primary btn-action mr-1">
                                    <i class="fas fa-pencil-alt"></i>
                            </a>
                            <a href="/dashboard/admin/transaction/delete/<?php echo e($transaction->id); ?>" class="btn btn-danger btn-action" onclick="return confirm ('Hapus transaksi?')">
                                    <i class="fas fa-trash"></i>
                            </a>
                          </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ditrois\resources\views/dashboard/admin/transactions.blade.php ENDPATH**/ ?>