<div class="navbar-bg"></div>
<nav class="navbar navbar-expand-lg main-navbar">
    <form class="mr-auto form-inline">
        <ul class="mr-3 navbar-nav">
            <li>
                <a href="#" data-toggle="sidebar" class="nav-link nav-link-lg">
                    <i class="fas fa-bars"></i>
                </a>
            </li>
            
        </ul>
        
    </form>
    <ul class="navbar-nav navbar-right">
        <li class="dropdown"><a href="#" data-toggle="dropdown"
                class="nav-link dropdown-toggle nav-link-lg nav-link-user">
                <i class="fas fa-user mr-2"></i>
                <div class="d-sm-none d-lg-inline-block">Hi, <?php echo e(Str::words(auth()->user()->name, 2)); ?></div>
            </a>
            <div class="dropdown-menu dropdown-menu-right">
                
                <a href="" class="dropdown-item has-icon">
                    <i class="far fa-user"></i> Profile
                </a>
                
                
                <div class="dropdown-divider"></div>
                <a class="dropdown-item has-icon text-danger" href="<?php echo e(route('dashboard')); ?>"
                onclick="event.preventDefault();
                    document.getElementById('logout-form').submit();">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>

                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </li>
    </ul>
</nav>
<?php /**PATH C:\ditrois\resources\views/dashboard/layout/navbar.blade.php ENDPATH**/ ?>